This is a theme for Internet Explorer 8 and above

To enable it just change the template option in config.php like below:
$config['template'] = 'ie8';